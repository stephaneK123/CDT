window.Seed = (function () {
  function generateVoteCount() {
    return Math.floor((Math.random() * 50) + 15);
  }

  const products = [
    {
      id: 1,
      title: 'Favorite class',
      description: 'Math',
      url: '#',
      votes: generateVoteCount(),
      submitterAvatarUrl: 'images/avatars/daniel.jpg',
      productImageUrl: 'images/products/math.jpg',
    },
    {
      id: 2,
      title: 'Favorite class',
      description: 'Science',
      url: '#',
      votes: generateVoteCount(),
      submitterAvatarUrl: 'images/avatars/kristy.png',
      productImageUrl: 'images/products/science.jpg',
    },
    {
      id: 3,
      title: 'Favorite class',
      description: 'Social Studies',
      url: '#',
      votes: generateVoteCount(),
      submitterAvatarUrl: 'images/avatars/veronika.jpg',
      productImageUrl: 'images/products/social.jpg',
    },
    {
      id: 4,
      title: 'Favorite class',
      description: 'Accounting',
      url: '#',
      votes: generateVoteCount(),
      submitterAvatarUrl: 'images/avatars/molly.png',
      productImageUrl: 'images/products/accounting.jpg',
    },
  ];

  return { products: products };
}());
